import pandas as pd
import csv
from datetime import datetime
from data_entry import get_date, get_amount, get_category, get_description
import matplotlib.pyplot as plt

class CSV:
    CSV_FILE = "finance_data.csv"
    COLUMNS = ["date", "amount", "category", "description"]
    FORMAT = "%d-%m-%Y"

    @classmethod
    def initialize_csv(cls):
        try:
            pd.read_csv(cls.CSV_FILE)
        except FileNotFoundError:
            df = pd.DataFrame(columns=cls.COLUMNS)
            df.to_csv(cls.CSV_FILE, index=False)

    @classmethod
    def add_entry(cls, date, amount, category, description):
        date = pd.to_datetime(date, format="mixed", dayfirst=True, errors="raise").strftime(cls.FORMAT)

        new_entry = {
            "date": date,
            "amount": float(amount),
            "category": category,
            "description": description
        }
        with open(cls.CSV_FILE, "a", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=cls.COLUMNS)
            writer.writerow(new_entry)
        print("Entry Added Successfully")

    @classmethod
    def get_transactions(cls, start_date, end_date):
        df = pd.read_csv(cls.CSV_FILE)

        # keep as datetime for filtering/plotting
        df["date"] = pd.to_datetime(df["date"], format="mixed", dayfirst=True, errors="coerce").dt.normalize()

        start_date_dt = datetime.strptime(start_date, cls.FORMAT)
        end_date_dt = datetime.strptime(end_date, cls.FORMAT)

        mask = (df["date"] >= start_date_dt) & (df["date"] <= end_date_dt)
        filtered_df = df.loc[mask].copy()

        if filtered_df.empty:
            print("No transactions found in the given date range.")
            return None  # ✅ important
        else:
            # for printing only (don’t overwrite df used for plotting)
            printable_df = filtered_df.copy()
            printable_df["date"] = printable_df["date"].dt.strftime(cls.FORMAT)

            print(f"Transactions from {start_date_dt.strftime(cls.FORMAT)} to {end_date_dt.strftime(cls.FORMAT)}")
            print(printable_df.to_string(index=False))

            total_income = filtered_df[filtered_df["category"] == "Income"]["amount"].sum()
            total_expense = filtered_df[filtered_df["category"] == "Expense"]["amount"].sum()
            net_balance = total_income - total_expense

            print("\nSummary:")
            print(f"\nTotal Income: {total_income:.2f}")
            print(f"Total Expense: {total_expense:.2f}")
            print(f"Net Balance: {net_balance:.2f}")

            return filtered_df  # ✅ return df so plotting works

def add():
    CSV.initialize_csv()
    date = get_date("Enter date for transaction (dd-mm-yyyy) or enter today's date: ", allow_default=True)
    amount = get_amount()
    category = get_category()
    description = get_description()
    CSV.add_entry(date, amount, category, description)

def plot_transactions(df):
    if df is None or df.empty:
        print("Nothing to plot.")
        return

    # ensure datetime index for resample
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"], format="mixed", dayfirst=True, errors="coerce")
    df.set_index("date", inplace=True)

    income_df = df[df["category"] == "Income"]["amount"].resample("D").sum()
    expense_df = df[df["category"] == "Expense"]["amount"].resample("D").sum()

    plt.figure(figsize=(10, 5))
    plt.plot(income_df.index, income_df.values, label="Income", color="green")
    plt.plot(expense_df.index, expense_df.values, label="Expense", color="red")
    plt.xlabel("Date")
    plt.ylabel("Amount")
    plt.title("Income and Expense Over Time")
    plt.legend()
    plt.grid(True)
    plt.show()

def main():
    while True:
        print("\nPersonal Finance Manager")
        print("1. Add Transaction")
        print("2. View Transactions")
        print("3. Exit")
        choice = input("Choose an option (1-3): ")

        if choice == "1":
            add()
        elif choice == "2":
            start_date = get_date("Enter start date (dd-mm-yyyy): ")
            end_date = get_date("Enter end date (dd-mm-yyyy): ")
            df = CSV.get_transactions(start_date, end_date)

            if input("Do you want to plot the transactions? (y/n): ").lower() == "y":
                plot_transactions(df)
        elif choice == "3":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()
