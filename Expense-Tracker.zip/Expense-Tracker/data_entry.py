from datetime import datetime

date_format='%d-%m-%Y'
CATEGORIES={'I':'Income','E':'Expense'}

def get_date(prompt,allow_default=False):
    date_str=input(prompt)
    if allow_default and not date_str:
        return datetime.today().strftime(date_format)
    try:
        valid_date=datetime.strptime(date_str,date_format)
        return valid_date.strftime(date_format)
    except ValueError:
        print("Invalid date format. Please use DD-MM-YYYY.")
        return get_date(prompt, allow_default)

def get_amount():
    try:
        amount=float(input("Enter amount: "))
        if amount<=0:
            print("Amount must be positive.")
            return get_amount()
        return amount
    
    except ValueError:
        print("Invalid amount. Please enter a numeric value.")
        return get_amount()
    
def get_category():
    category=input("Enter category:('I' For Income or 'E' for Expense): ").upper()
    if category in CATEGORIES:
        return CATEGORIES[category]
    else:
        print("Invalid category. Please enter 'I' for Income or 'E' for Expense.")
        return get_category()
    
    

def get_description():
    return input("Enter description('Optional'): ")